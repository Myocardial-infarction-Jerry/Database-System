package cn.simpleSystem.springboot_demo.entity;

import lombok.Data;

@Data
public class Course {
    private int cid;
    private String cname;
}
