package cn.simpleSystem.springboot_demo.entity;

import lombok.Data;

@Data
public class Class {
    private int clid;
    private String clname;
    private int did;
    private int tid;
}
