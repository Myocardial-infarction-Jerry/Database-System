package cn.simpleSystem.springboot_demo.entity;

import lombok.Data;

@Data
public class User {
    private String account;
    private String password;
}
