package cn.simpleSystem.springboot_demo.DAO;


import cn.simpleSystem.springboot_demo.entity.Class;

import java.util.List;

public interface ClassDao {
    List<Class> list();

}
