package cn.simpleSystem.springboot_demo.entity;

import lombok.Data;

import java.sql.Date;

@Data
public class Studentdelete {
    private long sid;
}


