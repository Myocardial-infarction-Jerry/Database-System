package cn.simpleSystem.springboot_demo.services;

import cn.simpleSystem.springboot_demo.entity.Class;

import java.util.List;

public interface ClassService {
    List<Class> list();
}
