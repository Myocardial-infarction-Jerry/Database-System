package cn.simpleSystem.springboot_demo.services;

import cn.simpleSystem.springboot_demo.entity.User;

public interface UserService {
    String login(User user);

}
