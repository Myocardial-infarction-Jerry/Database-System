<template>
  
</template>
<script setup lang="ts">
  import {} from 'naive-ui'
</script>
<style lang="less">
  
</style>